package com.springapp.model.login.Login;

/**
 * Created by george on 11/22/2014.
 */
public class LoginImpl implements Login{

}
